<?php
return require MODX_CORE_PATH.'components/payment/platron.inc.php';