<?php
return require MODX_CORE_PATH.'components/payment/paybox.inc.php';
